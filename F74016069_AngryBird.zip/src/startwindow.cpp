#include "startwindow.h"
#include "ui_startwindow.h"

startwindow::startwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::startwindow)
{
    ui->setupUi(this);
    QObject::connect(ui->start_btn,SIGNAL(clicked()),this,SLOT(on_start_btn_clicked()));
    QObject::connect(ui->start_btn,SIGNAL(clicked()),this,SLOT(hide()));
    QObject::connect(ui->quit_btn,SIGNAL(clicked()),this,SLOT(close()));
    //w.window=this;
}

startwindow::~startwindow()
{
    delete ui;
}

void startwindow::on_start_btn_clicked()
{
    w.show();
}
