#ifndef STARTWINDOW_H
#define STARTWINDOW_H

#include <QMainWindow>
#include "mainwindow.h"

namespace Ui {
class startwindow;
}

class startwindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit startwindow(QWidget *parent = 0);
    MainWindow w;
    ~startwindow();

private slots:
    void on_start_btn_clicked();

private:
    Ui::startwindow *ui;
};

#endif // STARTWINDOW_H
