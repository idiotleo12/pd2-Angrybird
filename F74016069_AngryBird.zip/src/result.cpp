#include "result.h"
#include "ui_result.h"

result::result(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::result)
{
    ui->setupUi(this);
}

result::~result()
{
    delete ui;
}

void result::on_end_btn_clicked()
{
    emit quit_game();
    this->close();
}

void result::on_restart_btn_clicked()
{
    emit restart_game();
    this->close();
}
