#ifndef RESULT_H
#define RESULT_H

#include <QDialog>

namespace Ui {
class result;
}

class result : public QDialog
{
    Q_OBJECT

public:
    explicit result(QWidget *parent = 0);
    ~result();

public slots:
    void on_end_btn_clicked();
    void on_restart_btn_clicked();
signals:
    void quit_game();
    void restart_game();


private:
    Ui::result *ui;
};

#endif // RESULT_H
