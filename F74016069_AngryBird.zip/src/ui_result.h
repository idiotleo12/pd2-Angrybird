/********************************************************************************
** Form generated from reading UI file 'result.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULT_H
#define UI_RESULT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_result
{
public:
    QPushButton *restart_btn;
    QPushButton *end_btn;

    void setupUi(QDialog *result)
    {
        if (result->objectName().isEmpty())
            result->setObjectName(QStringLiteral("result"));
        result->resize(472, 204);
        restart_btn = new QPushButton(result);
        restart_btn->setObjectName(QStringLiteral("restart_btn"));
        restart_btn->setGeometry(QRect(130, 140, 75, 23));
        end_btn = new QPushButton(result);
        end_btn->setObjectName(QStringLiteral("end_btn"));
        end_btn->setGeometry(QRect(260, 140, 75, 23));

        retranslateUi(result);

        QMetaObject::connectSlotsByName(result);
    } // setupUi

    void retranslateUi(QDialog *result)
    {
        result->setWindowTitle(QApplication::translate("result", "End of Game", 0));
        restart_btn->setText(QApplication::translate("result", "Restart", 0));
        end_btn->setText(QApplication::translate("result", "End", 0));
    } // retranslateUi

};

namespace Ui {
    class result: public Ui_result {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULT_H
