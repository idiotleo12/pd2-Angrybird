#ifndef MAINWINDOW_H
#define MAINWINDOW_H
//#include "startwindow.h"
#include "result.h"
#include <QMainWindow>
#include <QGraphicsScene>
#include <QList>
#include <QDesktopWidget>
#include <QTimer>
#include <Box2D/Box2D.h>
#include <QMouseEvent>
#include <iostream>

#include <gameitem.h>
#include <land.h>
#include <bird.h>
#include <barrier.h>
#include <pig.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void showEvent(QShowEvent *);
    bool eventFilter(QObject *,QEvent *event);
    void closeEvent(QCloseEvent *);
    //startwindow* window;
    QPoint p1,p2;
signals:
    // Signal for closing the game
    void quitGame();

private slots:
    void tick();
    void remove();
    // For debug slot
    void QUITSLOT();
    void refresh();
private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    b2World *world;
    QList<GameItem *> itemList;//land+bird
    QList<GameItem *> pigList;
    QList<GameItem *> wood;
    QTimer timer;
    QTimer * t;
    bool b;
    int birdMade;
    int birdKilled;
    Bird *bird1;
    Bird *bird2;
    Bird *bird3;
    Bird *bird4;
    Bird *bird5;
    Bird *bird6;
    Bird *bird7;
    result *r;
    Land *ground;
};

#endif // MAINWINDOW_H
