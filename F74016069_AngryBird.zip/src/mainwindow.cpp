#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <unistd.h>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    birdMade=1;
    birdKilled=0;
    t = new QTimer();
    b = true;
    ui->setupUi(this);
    // Enable the event Filter
    //qApp->installEventFilter(this);
    r=new result;
    connect(r,SIGNAL(quit_game()),this,SLOT(QUITSLOT()));
    connect(r,SIGNAL(restart_game()),this,SLOT(refresh()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showEvent(QShowEvent *)
{

    // Setting the QGraphicsScene
    scene = new QGraphicsScene(0,0,width(),ui->graphicsView->height());
    QGraphicsPixmapItem *bg=new QGraphicsPixmapItem();
    QImage bg_image(":/bg");
    QPixmap bg_pixmap = QPixmap::fromImage(bg_image);
    bg->setPixmap(bg_pixmap);
    bg->setZValue(-1);
    scene->addItem(bg);
    ui->graphicsView->setScene(scene);
    // Create world
    //world = new b2World(b2Vec2(0.0f, -9.8f));
    world = new b2World(b2Vec2(0.0f, 0.0f));
    // Setting Size
    GameItem::setGlobalSize(QSizeF(32,18),size());
    // Create ground (You can edit here)
    ground = new Land(16,1.5,32,3,QPixmap(":/ground.png").scaled(width(),height()/6.0),world,scene);
    itemList.push_back(ground);
    pig *pig1= new pig(11.0f,4.5f,&timer,QPixmap(":/pig").scaled(height()/9.0,height()/9.0),world,scene);
    pigList.push_front(pig1);
    // Create bird (You can edit here)
    bird1 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene,10.0f,0.2f,0.5f);
    barrier *bar= new barrier(10.0f,5.0f,1.7f,0.5f,&timer,QPixmap(":/wood1"),world,scene);
    itemList.push_back(bird1);
    wood.push_front(bar);
    // Setting the Velocity

    //itemList.push_back(bird1);

    qApp->installEventFilter(this);
    // Timer
    connect(&timer,SIGNAL(timeout()),this,SLOT(tick()));
    connect(this,SIGNAL(quitGame()),this,SLOT(QUITSLOT()));
    timer.start(100/6);
}

bool MainWindow::eventFilter(QObject *, QEvent *event)
{

    if(event->type() == QEvent::MouseButtonPress)
    {
        qDebug()<<"y:"<<wood.at(0)->getBody()->GetPosition().y;
        //qDebug()<<"height:"<<QPixmap(":/wood1").height();
        //qDebug()<<"ground y:"<<ground->getBody()->GetPosition().y;
    }


    // Hint: Notice the Number of every event!
    if(event->type() == QEvent::MouseButtonPress)
    {
        p1 = this->mapFromGlobal(QCursor::pos());
        //std::cout << "Press !" << std::endl ;
        //std::cout << p.x() << std::endl ;
    }
    if(event->type() == QEvent::MouseMove)
    {
        //std::cout << "Move !" << std::endl ;
    }
    if(event->type() == QEvent::MouseButtonRelease)
    {
        std::cout << "Release !" << std::endl ;
        //qDebug()<<"enter\n";
        p2 = this->mapFromGlobal(QCursor::pos());
        //std::cout<<(p1-p2).x()<<"\t"<<(p2-p1).y()<<std::endl;
        world->SetGravity(b2Vec2(0,-9.8));
        if(itemList.size()==2)
        {
            itemList.at(1)->setSpeed((p1-p2).x(),(p2-p1).y());
            //qDebug()<<"made:"<<birdMade;
        }

        connect(t,SIGNAL(timeout()),this,SLOT(remove()));

        t->start(5000);
        //qDebug()<<"leave\n";
    }

    return false;

}

void MainWindow::remove()
{
    qDebug()<<"remove";
    if(b==true)
    {
        qDebug()<<"b==true";
    world->SetGravity(b2Vec2(0.0f, 0.0f));
    if(itemList.size()==2)
    {
        world->DestroyBody(itemList.at(1)->getBody());
        itemList.removeAt(1);
        birdKilled++;
        qDebug()<<"kill"<<birdKilled;
    }

    //if(birdMade<7&&birdMade==birdKilled&&itemList.size()==1)
    if(birdMade<7&&birdMade==birdKilled&&itemList.size()==1)
    {
        birdMade++;
        qDebug()<<"make"<<birdMade;
        switch (birdMade) {
        case 2:
            bird2 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/blue").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird2);
            //qDebug()<<"2";
            break;
        case 3:
            bird3 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/none").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird3);
            //qDebug()<<"3";
            break;
        case 4:
            bird4 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/yellow").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird4);
            //qDebug()<<"4";
            break;
        case 5:
            bird5 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/none").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird5);
            //qDebug()<<"5";
            break;
        case 6:
            bird6 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/none").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird6);
            //qDebug()<<"6";
            break;
        case 7:
            bird7 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/white").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);
            itemList.push_back(bird7);
            //qDebug()<<"7";
            break;
        default:
            break;
        }
        //Bird *bird2 = new Bird(10.0f,10.0f,0.27f,&timer,QPixmap(":/blue").scaled(height()/9,height()/9.0),world,scene,10.0f,0.2f,0.5f);


        //qDebug()<<"Made";
    }}
    b=!b;
    if(birdKilled==7)
        r->show();
}


void MainWindow::closeEvent(QCloseEvent *)
{
    // Close event
    emit quitGame();
}

void MainWindow::tick()
{
    world->Step(1.0/60.0,6,2);
    scene->update();
}

void MainWindow::QUITSLOT()
{
    // For debug
    //std::cout << "Quit Game Signal receive !" << std::endl ;
    close();
}

void MainWindow::refresh()
{
    qDebug()<<"start to refresh";
    birdMade=1;
    birdKilled=0;
    b=false;
    //
    //scene->~QGraphicsScene();
    scene = new QGraphicsScene(0,0,width(),ui->graphicsView->height());
    ui->graphicsView->setScene(scene);
qDebug()<<"here 1";
    //world->~b2World();
    world = new b2World(b2Vec2(0.0f, 0.0f));
    qDebug()<<"here 2";
    itemList.clear();
    //ground.~GameItem();
    ground = new Land(16,1.5,32,3,QPixmap(":/ground.png").scaled(width(),height()/6.0),world,scene);
    itemList.push_front(ground);
    qDebug()<<"here 3";
    bird1 = new Bird(2.0f,10.0f,0.27f,&timer,QPixmap(":/bird.png").scaled(height()/9.0,height()/9.0),world,scene,10.0f,0.2f,0.5f);
    itemList.push_back(bird1);
    barrier *bar= new barrier(10.0f,5.0f,1.7f,0.5f,&timer,QPixmap(":/wood1"),world,scene);
    wood.clear();
    wood.push_front(bar);
qDebug()<<"here 4";
}
