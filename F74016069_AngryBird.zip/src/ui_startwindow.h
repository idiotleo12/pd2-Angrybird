/********************************************************************************
** Form generated from reading UI file 'startwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTWINDOW_H
#define UI_STARTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_startwindow
{
public:
    QWidget *centralwidget;
    QPushButton *start_btn;
    QPushButton *quit_btn;
    QLabel *label;

    void setupUi(QMainWindow *startwindow)
    {
        if (startwindow->objectName().isEmpty())
            startwindow->setObjectName(QStringLiteral("startwindow"));
        startwindow->resize(800, 600);
        centralwidget = new QWidget(startwindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        start_btn = new QPushButton(centralwidget);
        start_btn->setObjectName(QStringLiteral("start_btn"));
        start_btn->setGeometry(QRect(300, 240, 75, 23));
        quit_btn = new QPushButton(centralwidget);
        quit_btn->setObjectName(QStringLiteral("quit_btn"));
        quit_btn->setGeometry(QRect(460, 240, 75, 23));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(6, 1, 800, 600));
        label->setFrameShadow(QFrame::Plain);
        label->setPixmap(QPixmap(QString::fromUtf8("image/angry_birds___red_bird-wallpaper-800x600.jpg")));
        startwindow->setCentralWidget(centralwidget);
        label->raise();
        start_btn->raise();
        quit_btn->raise();

        retranslateUi(startwindow);

        QMetaObject::connectSlotsByName(startwindow);
    } // setupUi

    void retranslateUi(QMainWindow *startwindow)
    {
        startwindow->setWindowTitle(QApplication::translate("startwindow", "Angry Bird", 0));
        start_btn->setText(QApplication::translate("startwindow", "Play", 0));
        quit_btn->setText(QApplication::translate("startwindow", "Quit", 0));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class startwindow: public Ui_startwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTWINDOW_H
