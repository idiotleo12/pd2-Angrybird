#ifndef BARRIER_H
#define BARRIER_H


#include <gameitem.h>
#include <QPixmap>
#include <QGraphicsScene>
#include <QTimer>

class barrier : public GameItem
{
public:
    barrier(float x, float y, float xx,float yy, QTimer *timer, QPixmap pixmap, b2World *world, QGraphicsScene *scene);
private:

};

#endif // BARRIER_H
